The source code are all in the hw4_source_code.py
At the very beginning, the user need to replace or clarify the files' names / paths, which includes:

queryFileName -> The file contains all the queries needs to be matched
collectionFileName -> The file contains collection of all the documents or abstracts
outputFileName -> The name of the output file

The source code should be runned in any environment enabling Python coding with necessary extension, like VScode or Spyder.
Method used in optimization:
1) NLTK stemming
2) Modify the TF: apply log and divide count by length of documents
3) Elimination of items

PS: Since the original source code was written and tested in Google Colab, 
    I attached the link to my online file: https://colab.research.google.com/drive/1J8CpM5bjxEolbShYE3cZ-pyrFXq39-pN?usp=sharing
    All the NYU members are accessible to it.
    And also, I upload the ipynb file together in the zip.