The homework was mainly wrtiten in wx2056_HW3.py.
It's a one-person work.
In this file, 
the path of train file, test file and outputfile is easy to access at the beginning of the program.
I handle the OOV problem simply using assign 1/1000 probability to unknow words.


To professor, TA or grader,
It's my apology that several import events crashed into these few weeks and I obviously did not schedule my tasks well.
I have to prepare for upcoming GRE test, Math Modeling Competiton, linear algebra exam, econometrics exam, several project from other courses and of course NLP HW.
I feel relatively exhausted when working the homework out but I have managed to accomplished as much as I can in this assignment.
Although the outcome was pretty sad, I might only get 5% accuracy currently.
I would appreicate it if the grader could have a look at my code, although it must have logical or trivial problems.
They are all well managed and annotated, which in my hope would bring me some effort scores.
Sorry for the inconvenience caused by my such a long speech. 
Best wishes,
wx2056